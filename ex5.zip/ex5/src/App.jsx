import "./App.css";
import Singlepageapp from "./components/Spa";

function App() {
  return <Singlepageapp />;
}

export default App;
