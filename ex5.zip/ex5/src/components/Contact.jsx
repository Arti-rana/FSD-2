export default function Contact() {
  return (
    <div>
      <h2>Contact Page | 23BDA70082</h2>
    </div>
  );
}
