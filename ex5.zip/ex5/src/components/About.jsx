export default function About() {
  return (
    <div>
      <h2>About Page | 23BDA70082</h2>
    </div>
  );
}
