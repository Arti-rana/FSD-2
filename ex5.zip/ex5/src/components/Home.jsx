export default function Home() {
  return (
    <div>
      <h2>Home Page | 23BDA70082</h2>
    </div>
  );
}
